import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ListnewchatPage } from './listnewchat';

@NgModule({
  declarations: [
    ListnewchatPage,
  ],
  imports: [
    IonicPageModule.forChild(ListnewchatPage),
  ],
})
export class ListnewchatPageModule {}
